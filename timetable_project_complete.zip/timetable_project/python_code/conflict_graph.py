"""STEP 2 - Turn the timetable problem into a GRAPH.

    dot  (vertex) = one class
    line (edge)   = two classes that can NOT be at the same time
                    (same teacher OR same student group)
"""
from math import ceil


def build_graph(classes):
    graph = {c[0]: [] for c in classes}          # class_id -> list of clashing class_ids
    for i in range(len(classes)):
        for j in range(i + 1, len(classes)):
            a, b = classes[i], classes[j]
            same_teacher = a[2] == b[2]
            same_group = a[3] == b[3]
            if same_teacher or same_group:
                graph[a[0]].append(b[0])
                graph[b[0]].append(a[0])
    return graph


def lower_bound(classes, rooms):
    """Smallest number of slots any timetable could possibly use.
    - a teacher with 4 classes needs at least 4 different slots
    - a group with 5 classes needs at least 5 different slots
    - only `rooms` classes can run at the same time"""
    count = {}
    for _, _, teacher, group in classes:
        count[teacher] = count.get(teacher, 0) + 1
        count[group] = count.get(group, 0) + 1
    return max(max(count.values()), ceil(len(classes) / rooms))
