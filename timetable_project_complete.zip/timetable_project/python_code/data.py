"""STEP 1 - The input data.
A class is a tuple:  (class_id, subject, teacher, student_group)
"""
import random

DAYS = 5          # Monday to Friday
PERIODS = 6       # periods per day
TOTAL_SLOTS = DAYS * PERIODS   # 30 time slots in a week
ROOMS = 3         # number of rooms (so at most 3 classes can run at the same time)

SAMPLE_CLASSES = [
    (1 , "Chemistry",  "Prof D", "CSE-2"),
    (2 , "Maths",      "Prof A", "CSE-2"),
    (3 , "Maths",      "Prof A", "CSE-1"),
    (4 , "Chemistry",  "Prof D", "CSE-3"),
    (5 , "English",    "Prof E", "CSE-3"),
    (6 , "English",    "Prof E", "CSE-1"),
    (7 , "Physics",    "Prof B", "CSE-3"),
    (8 , "Physics",    "Prof B", "CSE-1"),
    (9 , "DAA",        "Prof C", "CSE-2"),
    (10, "DAA",        "Prof C", "CSE-1"),
    (11, "Maths",      "Prof A", "CSE-3"),
    (12, "DAA",        "Prof C", "CSE-3"),
]


def random_classes(n, seed=1):
    """Make n random classes (used for testing bigger inputs)."""
    rng = random.Random(seed)
    n_teachers = max(2, n // 4)
    n_groups = max(2, n // 6)
    classes = []
    for i in range(1, n + 1):
        teacher = f"Prof {rng.randint(1, n_teachers)}"
        group = f"G{rng.randint(1, n_groups)}"
        classes.append((i, f"Sub{rng.randint(1, 20)}", teacher, group))
    return classes


# ---- College-style input used by the GUI: (student group, subject, teacher, lectures per week)
COLLEGE_SAMPLE = [
    ("CSE-A", "DAA",   "Prof Shah",   2), ("CSE-A", "DBMS",  "Prof Mehta", 2),
    ("CSE-A", "OS",    "Prof Patel",  1), ("CSE-A", "Maths", "Prof Joshi", 1),
    ("CSE-B", "DAA",   "Prof Shah",   2), ("CSE-B", "DBMS",  "Prof Desai", 1),
    ("CSE-B", "OS",    "Prof Patel",  2), ("CSE-B", "Maths", "Prof Joshi", 1),
    ("IT-A",  "DAA",   "Prof Bhatt",  1), ("IT-A",  "DBMS",  "Prof Mehta", 1),
    ("IT-A",  "OS",    "Prof Desai",  2), ("IT-A",  "Maths", "Prof Joshi", 1),
]


def expand_lectures(rows):
    """(group, subject, teacher, lectures) -> one class per lecture."""
    classes = []
    for group, subject, teacher, lectures in rows:
        for _ in range(lectures):
            classes.append((len(classes) + 1, subject, teacher, group))
    return classes
