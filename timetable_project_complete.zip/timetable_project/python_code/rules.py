"""The ONE rule used by every algorithm: can class `c` go in time slot `slot`?"""


def why_not(c, slot, graph, slot_of, used, rooms):
    """Return the reason a class can NOT go in this slot (or None if it can)."""
    # Rule 1 (room): the slot must not be full
    if used.get(slot, 0) >= rooms:
        return f"all {rooms} rooms are already used"
    # Rule 2 (teacher/group): no clashing class may already be in this slot
    for other in graph[c]:
        if slot_of.get(other) == slot:
            return f"clashes with class {other} (same teacher or same student group)"
    return None


def is_safe(c, slot, graph, slot_of, used, rooms):
    return why_not(c, slot, graph, slot_of, used, rooms) is None


def record(log, *event):
    """Only used by the GUI to replay the algorithm step by step.
    (log is None when you run main.py, so nothing happens.)"""
    if log is not None and len(log) < 5000:
        log.append(event)
