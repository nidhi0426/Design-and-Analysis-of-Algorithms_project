# Simple University Timetable Optimization (DAA Mini Project)

## Run the GUI (recommended for the demo)
```
python gui.py
```
No installation needed (tkinter comes with Python). 4 tabs: Input data, Graph & algorithm, Timetable, Compare.

## Run in the terminal (optional)
```
python main.py          # 12 sample classes, runs all 3 algorithms, prints the timetable
python main.py 30       # 30 random classes
python compare.py       # time vs input size (also saves compare_chart.png)
```
No extra libraries needed (matplotlib only for the chart: `pip install matplotlib`).

## The idea in 4 lines
1. Every class is a DOT.
2. Two classes that cannot be together (same teacher or same student group) are joined by a LINE.
3. Every time slot is a COLOUR.
4. Colour the dots so joined dots never share a colour -> a timetable with no clashes.
   Fewer colours = fewer slots used.

## Files (one job each)
| File | Job | Explain it as |
|---|---|---|
| `data.py` | Input classes, rooms, slots | "This is our input" |
| `conflict_graph.py` | Builds the dots-and-lines graph + lower bound | "Convert the problem into a graph" |
| `rules.py` | `is_safe()`: can this class go in this slot? | "The only rule: no teacher/group clash, room not full" |
| `algo1_graph_coloring.py` | Algorithm 1: colour in given order | "Basic method, order is random" |
| `algo2_greedy.py` | Algorithm 2: sort hardest class first | "Same method, but sorted: Welsh-Powell greedy" |
| `algo3_backtracking.py` | Algorithm 3: try, undo, retry | "Exact method, finds the fewest slots" |
| `checker.py` | Proves the timetable has 0 clashes | "Verification" |
| `show.py` | Prints the timetable | "Output" |
| `gui.py` | The window (tabs, graph drawing, step-by-step) | "The demo screen" |
| `main.py` | Same demo, text only | "Terminal demo" |
| `compare.py` | Tests 10 to 100 classes | "Performance comparison" |

## The 3 algorithms
**1. Graph colouring (basic):** for each class in input order, give it the first safe slot.
**2. Greedy (Welsh-Powell):** same, but first sort classes by number of clashes (most clashes first).
**3. Backtracking:** for k = lower bound, +1, +2 ...: try to fit all classes into k slots.
Place a class, go to the next one; if stuck, undo the last choice and try another slot. First k that works is the best.

## Complexity (V = classes, E = clashes, k = slots)
| Algorithm | Best | Average | Worst | Space |
|---|---|---|---|---|
| Graph colouring | O(V + E) | O(V^2) | O(V^2) | O(V + E) |
| Greedy | O(V log V + E) | O(V^2) | O(V^2) | O(V + E) |
| Backtracking | O(V) (first try works) | exponential | O(k^V) | O(V) recursion |

## What the results show
- On the sample, basic colouring needs 6 slots, greedy and backtracking need 5 (= the lower bound, so 5 is optimal).
- Greedy is almost as fast as basic colouring and usually as good or better, but not always (random data).
- Backtracking gives the best answer but "gives up" at 100 classes (too many steps): exponential growth.

## Limits
Rooms are just a count (no capacity sizes); one period per class; no teacher preferences.
