"""Print a timetable in a readable way."""
from data import DAYS

DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]


def show_timetable(classes, slot_of):
    info = {c[0]: c for c in classes}
    for slot in sorted(set(slot_of.values())):
        day = DAY_NAMES[slot % DAYS]            # spread the slots over the week
        period = slot // DAYS + 1
        ids = [c for c in slot_of if slot_of[c] == slot]
        parts = []
        for room_no, c in enumerate(ids, start=1):
            _, subject, teacher, group = info[c]
            parts.append(f"{subject} ({teacher}, {group}, Room {room_no})")
        print(f"  {day} P{period}:  " + "  |  ".join(parts))
