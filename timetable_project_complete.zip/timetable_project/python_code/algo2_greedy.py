"""ALGORITHM 2 - Greedy (Welsh-Powell).

Idea:  SAME as basic colouring, but first SORT the classes so the
       most-clashing class (most lines in the graph) goes first.
       Hardest classes first = fewer wasted slots.
Fast:  time O(V^2), space O(V + E).   (V = classes, E = clashes)
"""
from rules import is_safe, record, why_not


def greedy(classes, graph, rooms, total_slots, log=None):
    # the only new line: sort by number of clashes, biggest first
    order = sorted(graph, key=lambda c: len(graph[c]), reverse=True)
    record(log, "order", order)

    slot_of = {}
    used = {}
    for c in order:
        for slot in range(total_slots):
            if is_safe(c, slot, graph, slot_of, used, rooms):
                slot_of[c] = slot
                used[slot] = used.get(slot, 0) + 1
                record(log, "place", c, slot)
                break
            record(log, "reject", c, slot, why_not(c, slot, graph, slot_of, used, rooms))
    return slot_of
