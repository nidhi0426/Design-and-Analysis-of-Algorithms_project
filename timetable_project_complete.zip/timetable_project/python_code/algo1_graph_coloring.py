"""ALGORITHM 1 - Basic graph colouring (in the order the classes are given).

Idea:  go through the classes one by one and give each class the
       FIRST slot (colour) that is safe.
Problem: the order is random, so it can waste slots.
"""
from rules import is_safe, record, why_not


def basic_coloring(classes, graph, rooms, total_slots, log=None):
    slot_of = {}      # class_id -> slot number
    used = {}         # slot number -> how many classes are in it

    order = [cl[0] for cl in classes]            # same order as the input
    record(log, "order", order)

    for c in order:
        for slot in range(total_slots):          # try slot 0, 1, 2 ...
            if is_safe(c, slot, graph, slot_of, used, rooms):
                slot_of[c] = slot
                used[slot] = used.get(slot, 0) + 1
                record(log, "place", c, slot)
                break                            # first safe slot wins
            record(log, "reject", c, slot, why_not(c, slot, graph, slot_of, used, rooms))
    return slot_of
