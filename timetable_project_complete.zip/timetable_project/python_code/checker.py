"""Check that a timetable has NO clashes."""


def check_timetable(classes, slot_of, rooms):
    problems = []
    for c in classes:
        if c[0] not in slot_of:
            problems.append(f"class {c[0]} was not placed")
    for i in range(len(classes)):
        for j in range(i + 1, len(classes)):
            a, b = classes[i], classes[j]
            if a[0] in slot_of and b[0] in slot_of and slot_of[a[0]] == slot_of[b[0]]:
                if a[2] == b[2]:
                    problems.append(f"{a[2]} teaches classes {a[0]} and {b[0]} at the same time")
                if a[3] == b[3]:
                    problems.append(f"group {a[3]} has classes {a[0]} and {b[0]} at the same time")
    count = {}
    for s in slot_of.values():
        count[s] = count.get(s, 0) + 1
    for s, n in count.items():
        if n > rooms:
            problems.append(f"slot {s} has {n} classes but only {rooms} rooms")
    return problems
