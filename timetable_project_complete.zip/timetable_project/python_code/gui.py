"""THE GUI.   Run:  python gui.py

Tab 1  Input data       - add student groups, subjects, teachers
Tab 2  Graph & algorithm - see the conflict graph, run an algorithm, watch it step by step
Tab 3  Timetable        - weekly timetable for a student group or a teacher
Tab 4  Compare          - all 3 algorithms side by side
"""
import time
import tkinter as tk
from math import cos, pi, sin
from tkinter import messagebox, ttk

from algo1_graph_coloring import basic_coloring
from algo2_greedy import greedy
from algo3_backtracking import backtracking
from checker import check_timetable
from conflict_graph import build_graph, lower_bound
from data import COLLEGE_SAMPLE, expand_lectures

BASIC, GREEDY, BT = "1. Graph colouring", "2. Greedy (Welsh-Powell)", "3. Backtracking"
SHORT = {BASIC: "Colouring", GREEDY: "Greedy", BT: "Backtracking"}
DESCRIPTION = {
    BASIC: "Take the classes one by one in the order they were typed. Give each class the FIRST "
           "slot that is safe (no teacher/group clash, a room is free).\n\nSimple, but the order is "
           "random, so slots can be wasted.",
    GREEDY: "Same as basic colouring, but first SORT the classes: the class with the MOST clashes "
            "goes first. Hardest classes first means fewer wasted slots.\n\nFast: O(V\u00b2).",
    BT: "Ask: can ALL classes fit in k slots? Try a slot for a class; if we get stuck, UNDO the "
        "last choice (backtrack) and try another slot. The first k that works is the BEST possible "
        "answer.\n\nExact, but exponential O(k^V): slow for big inputs.",
}
BG = "#f5f7fb"
SLOT_COLORS = ["#2563eb", "#dc2626", "#16a34a", "#9333ea", "#ea580c", "#0891b2", "#ca8a04",
               "#db2777", "#4f46e5", "#65a30d", "#0d9488", "#b45309", "#7c3aed", "#e11d48"]
PASTELS = ["#dbeafe", "#fee2e2", "#dcfce7", "#f3e8ff", "#ffedd5", "#cffafe", "#fef9c3", "#fce7f3",
           "#e0e7ff", "#ecfccb"]
EDGE_TEACHER, EDGE_GROUP, EDGE_BOTH = "#60a5fa", "#fb923c", "#a855f7"
DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]


def run_algo(name, classes, graph, rooms, total_slots, log=None):
    """Run one algorithm and measure it."""
    t = time.perf_counter()
    if name == BASIC:
        slot_of, steps, status = basic_coloring(classes, graph, rooms, total_slots, log), len(classes), "found"
    elif name == GREEDY:
        slot_of, steps, status = greedy(classes, graph, rooms, total_slots, log), len(classes), "found"
    else:
        slot_of, steps, status = backtracking(classes, graph, rooms, total_slots, 100000, log)
    return {"slot_of": slot_of, "ms": (time.perf_counter() - t) * 1000, "steps": steps, "status": status}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("College Timetable Optimizer - Graph Colouring | Greedy | Backtracking")
        self.geometry("1200x740")
        self.minsize(1100, 700)
        self.configure(bg=BG)
        ttk.Style(self).theme_use("clam")

        self.classes, self.graph, self.info, self.results = [], {}, {}, {}
        self.events, self.ev_i, self.ready, self.pending = [], 0, False, None
        self.view_slots, self.playing, self.pos = {}, False, {}
        self.rooms_var, self.days_var, self.periods_var = tk.IntVar(value=3), tk.IntVar(value=5), tk.IntVar(value=6)
        self.algo_var = tk.StringVar(value=BASIC)

        tk.Label(self, text="College Timetable Optimizer", font=("Segoe UI", 17, "bold"), bg=BG, fg="#1b2a49").pack(pady=(8, 0))
        tk.Label(self, text="Dot = one class     Line = clash (same teacher or same student group)     Colour = time slot",
                 font=("Segoe UI", 10), bg=BG, fg="#6b7689").pack()
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=10, pady=8)
        self.tabs = [ttk.Frame(self.nb) for _ in range(4)]
        for tab, title in zip(self.tabs, ["1. Input data", "2. Graph & algorithm", "3. Timetable", "4. Compare"]):
            self.nb.add(tab, text=f"  {title}  ")
        self.build_input_tab()
        self.build_algo_tab()
        self.build_timetable_tab()
        self.build_compare_tab()
        self.load_sample()

    # ------------------------------------------------------------------ settings helpers
    def num(self, var, default, lo, hi):
        try:
            return max(lo, min(hi, int(var.get())))
        except (tk.TclError, ValueError):
            return default

    def rooms(self): return self.num(self.rooms_var, 3, 1, 50)
    def days(self): return self.num(self.days_var, 5, 1, 6)
    def periods(self): return self.num(self.periods_var, 6, 1, 8)
    def total_slots(self): return self.days() * self.periods()

    # ------------------------------------------------------------------ TAB 1: input
    def build_input_tab(self):
        t = self.tabs[0]
        left = ttk.Frame(t); left.pack(side="left", fill="y", padx=12, pady=12)
        box = ttk.LabelFrame(left, text=" Add lectures "); box.pack(fill="x")
        self.group_var, self.subject_var, self.teacher_var, self.lect_var = tk.StringVar(), tk.StringVar(), tk.StringVar(), tk.StringVar(value="2")
        ttk.Label(box, text="Student group (e.g. CSE-A)").grid(row=0, column=0, sticky="w", padx=8, pady=(8, 0))
        self.group_box = ttk.Combobox(box, textvariable=self.group_var, width=24)
        self.group_box.grid(row=1, column=0, padx=8, pady=2)
        ttk.Label(box, text="Subject (e.g. DAA)").grid(row=2, column=0, sticky="w", padx=8, pady=(6, 0))
        ttk.Entry(box, textvariable=self.subject_var, width=27).grid(row=3, column=0, padx=8, pady=2)
        ttk.Label(box, text="Teacher (e.g. Prof Shah)").grid(row=4, column=0, sticky="w", padx=8, pady=(6, 0))
        ttk.Entry(box, textvariable=self.teacher_var, width=27).grid(row=5, column=0, padx=8, pady=2)
        ttk.Label(box, text="Lectures per week").grid(row=6, column=0, sticky="w", padx=8, pady=(6, 0))
        ttk.Spinbox(box, from_=1, to=6, textvariable=self.lect_var, width=6).grid(row=7, column=0, sticky="w", padx=8, pady=2)
        ttk.Button(box, text="+ Add to list", command=self.add_lectures).grid(row=8, column=0, padx=8, pady=10, sticky="we")

        sbox = ttk.LabelFrame(left, text=" College settings "); sbox.pack(fill="x", pady=12)
        for r, (label, var, lo, hi) in enumerate([("Rooms available", self.rooms_var, 1, 50),
                                                  ("Days per week", self.days_var, 1, 6),
                                                  ("Periods per day", self.periods_var, 1, 8)]):
            ttk.Label(sbox, text=label).grid(row=r, column=0, sticky="w", padx=8, pady=4)
            ttk.Spinbox(sbox, from_=lo, to=hi, textvariable=var, width=6, command=self.clear_results).grid(row=r, column=1, padx=8)
        ttk.Button(left, text="Load sample college data", command=self.load_sample).pack(fill="x", pady=2)
        ttk.Button(left, text="Clear all", command=self.clear_all).pack(fill="x", pady=2)

        right = ttk.Frame(t); right.pack(side="left", fill="both", expand=True, padx=(0, 12), pady=12)
        self.count_label = ttk.Label(right, text="", font=("Segoe UI", 11, "bold")); self.count_label.pack(anchor="w")
        cols = ("id", "group", "subject", "teacher")
        self.tree = ttk.Treeview(right, columns=cols, show="headings", height=18)
        for c, w in zip(cols, (60, 140, 160, 180)):
            self.tree.heading(c, text=c.capitalize() if c != "id" else "Class #")
            self.tree.column(c, width=w, anchor="w")
        sb = ttk.Scrollbar(right, command=self.tree.yview); self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True, pady=6); sb.pack(side="left", fill="y", pady=6)
        ttk.Button(right, text="Delete selected", command=self.delete_selected).pack(anchor="ne", padx=8)

    def add_lectures(self):
        g, s, tch = self.group_var.get().strip(), self.subject_var.get().strip(), self.teacher_var.get().strip()
        if not (g and s and tch):
            messagebox.showwarning("Missing data", "Please fill the student group, subject and teacher.")
            return
        n = self.num(self.lect_var, 1, 1, 6)
        for _ in range(n):
            self.classes.append((0, s, tch, g))
        self.subject_var.set("")
        self.refresh()

    def delete_selected(self):
        ids = {int(self.tree.item(i)["values"][0]) for i in self.tree.selection()}
        self.classes = [c for c in self.classes if c[0] not in ids]
        self.refresh()

    def load_sample(self):
        self.rooms_var.set(3); self.days_var.set(5); self.periods_var.set(6)
        self.classes = expand_lectures(COLLEGE_SAMPLE)
        self.refresh()

    def clear_all(self):
        self.classes = []
        self.refresh()

    def refresh(self):
        """Called whenever the input changes: renumber, rebuild the graph, clear old results."""
        self.classes = [(i + 1, s, t, g) for i, (_, s, t, g) in enumerate(self.classes)]
        self.info = {c[0]: c for c in self.classes}
        self.tree.delete(*self.tree.get_children())
        for c in self.classes:
            self.tree.insert("", "end", values=(c[0], c[3], c[1], c[2]))
        self.group_box["values"] = sorted({c[3] for c in self.classes})
        self.graph = build_graph(self.classes)
        self.layout_nodes()
        self.clear_results()

    # ------------------------------------------------------------------ TAB 2: graph & algorithm
    def build_algo_tab(self):
        t = self.tabs[1]
        left = ttk.Frame(t); left.pack(side="left", fill="both", expand=True, padx=8, pady=8)
        self.canvas = tk.Canvas(left, width=680, height=580, bg="white", highlightthickness=1, highlightbackground="#d5dbe6")
        self.canvas.pack()
        self.node_label = ttk.Label(left, text="Click a dot to see which class it is.", font=("Segoe UI", 10))
        self.node_label.pack(anchor="w", pady=4)

        right = ttk.Frame(t, width=430); right.pack(side="left", fill="y", padx=(0, 8), pady=8)
        right.pack_propagate(False)
        box = ttk.LabelFrame(right, text=" Choose algorithm "); box.pack(fill="x")
        for name in (BASIC, GREEDY, BT):
            ttk.Radiobutton(box, text=name, value=name, variable=self.algo_var, command=self.on_algo_change).pack(anchor="w", padx=8, pady=2)
        self.desc = tk.Label(box, text="", wraplength=390, justify="left", bg="#eef2f9", font=("Segoe UI", 10), padx=8, pady=6, anchor="w")
        self.desc.pack(fill="x", padx=8, pady=6)

        ttk.Button(right, text="\u25b6  Run (instant result)", command=self.run_instant).pack(fill="x", pady=(8, 2))
        step = ttk.LabelFrame(right, text=" Step by step (best for explaining) "); step.pack(fill="x", pady=6)
        row = ttk.Frame(step); row.pack(fill="x", padx=6, pady=6)
        ttk.Button(row, text="Reset", width=7, command=self.prepare_steps).pack(side="left", padx=2)
        ttk.Button(row, text="Next step \u25b6", command=self.next_step).pack(side="left", padx=2)
        self.play_btn = ttk.Button(row, text="Auto play", width=9, command=self.toggle_play); self.play_btn.pack(side="left", padx=2)
        ttk.Button(row, text="Skip to end", command=self.skip_to_end).pack(side="left", padx=2)
        srow = ttk.Frame(step); srow.pack(fill="x", padx=8, pady=(0, 6))
        ttk.Label(srow, text="Speed:").pack(side="left")
        self.speed = tk.IntVar(value=500)
        ttk.Scale(srow, from_=1000, to=80, variable=self.speed, length=140).pack(side="left", padx=6)
        ttk.Label(srow, text="slow \u2190 \u2192 fast", foreground="#6b7689").pack(side="left")

        self.result_label = tk.Label(right, text="", wraplength=410, justify="left", bg=BG, font=("Segoe UI", 10, "bold"), fg="#1b2a49", anchor="w")
        self.result_label.pack(fill="x", pady=4)
        lf = ttk.Frame(right); lf.pack(fill="both", expand=True)
        self.log = tk.Text(lf, height=14, width=48, wrap="word", font=("Segoe UI", 9), state="disabled", bg="white")
        lsb = ttk.Scrollbar(lf, command=self.log.yview); self.log.configure(yscrollcommand=lsb.set)
        self.log.pack(side="left", fill="both", expand=True); lsb.pack(side="left", fill="y")
        self.log.tag_configure("head", font=("Segoe UI", 9, "bold"), foreground="#1b2a49")
        self.log.tag_configure("place", foreground="#15803d")
        self.log.tag_configure("reject", foreground="#6b7689")
        self.log.tag_configure("undo", foreground="#b91c1c", font=("Segoe UI", 9, "bold"))
        self.on_algo_change()

    def layout_nodes(self):
        """Put the dots on a circle, classes of the same student group next to each other."""
        ordered = sorted(self.classes, key=lambda c: (c[3], c[0]))
        n, cx, cy = max(1, len(ordered)), 340, 285
        radius = 225
        self.pos = {c[0]: (cx + radius * cos(2 * pi * k / n - pi / 2), cy + radius * sin(2 * pi * k / n - pi / 2))
                    for k, c in enumerate(ordered)}

    def draw_graph(self, highlight=None):
        cv = self.canvas
        cv.delete("all")
        if not self.classes:
            cv.create_text(340, 290, text="No classes yet.\nAdd some in tab 1.", font=("Segoe UI", 14), fill="#6b7689")
            return
        for a in self.graph:                                  # lines = clashes
            for b in self.graph[a]:
                if a < b:
                    same_t, same_g = self.info[a][2] == self.info[b][2], self.info[a][3] == self.info[b][3]
                    colour = EDGE_BOTH if (same_t and same_g) else EDGE_TEACHER if same_t else EDGE_GROUP
                    cv.create_line(*self.pos[a], *self.pos[b], fill=colour, width=1.5)
        r = max(11, min(18, 330 // len(self.classes)))
        for c, (x, y) in self.pos.items():                     # dots = classes
            slot = self.view_slots.get(c)
            fill = SLOT_COLORS[slot % len(SLOT_COLORS)] if slot is not None else "#d9dee7"
            outline, width = ("#000000", 4) if c == highlight else ("white", 2)
            cv.create_oval(x - r, y - r, x + r, y + r, fill=fill, outline=outline, width=width, tags=f"n{c}")
            cv.create_text(x, y, text=str(c), fill="white" if slot is not None else "#1b2a49", font=("Segoe UI", 9, "bold"), tags=f"n{c}")
            cv.tag_bind(f"n{c}", "<Button-1>", lambda e, c=c: self.show_node(c))
        # legends
        cv.create_text(12, 560, anchor="w", text="Line colour:", font=("Segoe UI", 9, "bold"))
        for k, (col, txt) in enumerate([(EDGE_TEACHER, "same teacher"), (EDGE_GROUP, "same student group"), (EDGE_BOTH, "both")]):
            x0 = 100 + k * 175
            cv.create_line(x0, 560, x0 + 24, 560, fill=col, width=3)
            cv.create_text(x0 + 30, 560, anchor="w", text=txt, font=("Segoe UI", 9))
        used = sorted(set(self.view_slots.values()))
        if used:
            cv.create_text(12, 14, anchor="w", text="Slot colours:", font=("Segoe UI", 9, "bold"))
            for k, s in enumerate(used[:22]):
                cv.create_rectangle(12, 30 + k * 18, 24, 42 + k * 18, fill=SLOT_COLORS[s % len(SLOT_COLORS)], outline="")
                cv.create_text(30, 36 + k * 18, anchor="w", text=f"Slot {s + 1}", font=("Segoe UI", 9))

    def show_node(self, c):
        _, subject, teacher, group = self.info[c]
        text = f"Class {c}: {subject} | {teacher} | {group}"
        if c in self.view_slots:
            text += f"   \u2192  Slot {self.view_slots[c] + 1}"
        self.node_label.config(text=text)

    def on_algo_change(self):
        self.desc.config(text=DESCRIPTION[self.algo_var.get()])
        self.stop_play()
        self.ready = False
        self.view_slots = {}
        self.draw_graph()
        self.result_label.config(text="")
        self.log_clear()

    def clear_results(self):
        self.results = {}
        self.stop_play()
        self.ready, self.view_slots = False, {}
        self.draw_graph()
        if hasattr(self, "result_label"):
            edges = sum(len(v) for v in self.graph.values()) // 2
            self.count_label.config(text=f"{len(self.classes)} classes  |  {edges} clashes (lines)  |  lower bound: "
                                         f"{lower_bound(self.classes, self.rooms()) if self.classes else 0} slots")
            self.result_label.config(text="")
            self.log_clear()
            self.update_compare_table()
            self.update_tt_choices()

    # ---- logging box
    def log_clear(self):
        self.log.config(state="normal"); self.log.delete("1.0", "end"); self.log.config(state="disabled")

    def log_add(self, text, tag=None):
        self.log.config(state="normal"); self.log.insert("end", text + "\n", tag); self.log.see("end"); self.log.config(state="disabled")

    # ---- run instantly
    def finish(self, name, res, note=""):
        slot_of = res["slot_of"]
        self.results[name] = res
        if not slot_of:
            self.view_slots = {}
            self.result_label.config(text=f"{name}: {res['status']} after {res['steps']} steps.\nThis is why backtracking is only for small inputs.", fg="#b91c1c")
        else:
            self.view_slots = dict(slot_of)
            clashes = len(check_timetable(self.classes, slot_of, self.rooms()))
            self.result_label.config(
                text=f"{name}\nSlots used: {len(set(slot_of.values()))}  (lower bound {lower_bound(self.classes, self.rooms())})   "
                     f"Time: {res['ms']:.2f} ms\nSteps: {res['steps']}   Clashes: {clashes}{note}", fg="#1b2a49")
        self.draw_graph()
        if slot_of:
            self.tt_alg.set(name)
        self.update_compare_table()
        self.update_tt_choices()

    def need_classes(self):
        if not self.classes:
            messagebox.showinfo("No data", "Add some classes in tab 1 first (or load the sample data).")
            return False
        return True

    def run_instant(self):
        if not self.need_classes():
            return
        self.stop_play()
        name = self.algo_var.get()
        self.ready = False
        self.log_clear()
        res = run_algo(name, self.classes, self.graph, self.rooms(), self.total_slots())
        self.log_add(f"{name}: finished. Use 'Step by step' to watch how it works.", "head")
        self.finish(name, res)

    # ---- step by step
    def prepare_steps(self):
        if not self.need_classes():
            return False
        self.stop_play()
        name = self.algo_var.get()
        self.events = []
        self.pending = run_algo(name, self.classes, self.graph, self.rooms(), self.total_slots(), self.events)
        self.ev_i, self.ready, self.view_slots = 0, True, {}
        self.result_label.config(text="")
        self.log_clear()
        self.log_add(f"{name}  -  press 'Next step' or 'Auto play'", "head")
        self.draw_graph()
        return True

    def cls_text(self, c):
        _, s, t, g = self.info[c]
        return f"class {c} ({s}, {t}, {g})"

    def next_step(self):
        if not self.ready and not self.prepare_steps():
            return
        if self.ev_i >= len(self.events):
            self.end_steps()
            return
        ev = self.events[self.ev_i]
        self.ev_i += 1
        kind, hi = ev[0], None
        if kind == "order":
            self.log_add("Order of processing (class numbers):\n" + ", ".join(str(c) for c in ev[1]), "head")
        elif kind == "start_k":
            self.log_add(f"\n--- Can everything fit in {ev[1]} slots? ---", "head")
        elif kind == "failed_k":
            self.log_add(f"No. {ev[1]} slots is impossible, try {ev[1] + 1}.", "undo")
        elif kind == "reject":
            self.log_add(f"      Slot {ev[2] + 1} rejected: {ev[3]}", "reject")
            hi = ev[1]
        elif kind == "place":
            self.view_slots[ev[1]] = ev[2]
            self.log_add(f"\u2714 {self.cls_text(ev[1])} -> Slot {ev[2] + 1}", "place")
            hi = ev[1]
        elif kind == "undo":
            self.view_slots.pop(ev[1], None)
            self.log_add(f"\u21a9 UNDO: {self.cls_text(ev[1])} leaves Slot {ev[2] + 1} (stuck, backtrack)", "undo")
            hi = ev[1]
        self.draw_graph(highlight=hi)
        if self.ev_i >= len(self.events):
            self.end_steps()

    def end_steps(self):
        self.stop_play()
        cut = " (step log was cut at 5000 steps)" if len(self.events) >= 5000 else ""
        self.log_add("\nFinished." + cut, "head")
        self.finish(self.algo_var.get(), self.pending)
        self.ready = False

    def skip_to_end(self):
        if not self.ready and not self.prepare_steps():
            return
        self.ev_i = len(self.events)
        self.end_steps()

    def toggle_play(self):
        if self.playing:
            self.stop_play()
            return
        if not self.ready and not self.prepare_steps():
            return
        self.playing = True
        self.play_btn.config(text="Pause")
        self.tick()

    def tick(self):
        if not self.playing:
            return
        self.next_step()
        if self.playing:
            self.after(int(self.speed.get()), self.tick)

    def stop_play(self):
        self.playing = False
        if hasattr(self, "play_btn"):
            self.play_btn.config(text="Auto play")

    # ------------------------------------------------------------------ TAB 3: timetable
    def build_timetable_tab(self):
        t = self.tabs[2]
        top = ttk.Frame(t); top.pack(fill="x", padx=12, pady=10)
        self.tt_alg, self.tt_mode, self.tt_who = tk.StringVar(), tk.StringVar(value="Student group"), tk.StringVar()
        ttk.Label(top, text="Result of:").pack(side="left")
        self.tt_alg_box = ttk.Combobox(top, textvariable=self.tt_alg, state="readonly", width=24); self.tt_alg_box.pack(side="left", padx=6)
        ttk.Label(top, text="View by:").pack(side="left", padx=(12, 0))
        mode = ttk.Combobox(top, textvariable=self.tt_mode, values=["Student group", "Teacher"], state="readonly", width=14)
        mode.pack(side="left", padx=6)
        self.tt_who_box = ttk.Combobox(top, textvariable=self.tt_who, state="readonly", width=18); self.tt_who_box.pack(side="left", padx=6)
        for w in (self.tt_alg_box, mode, self.tt_who_box):
            w.bind("<<ComboboxSelected>>", lambda e: self.update_tt_choices(keep=True))
        self.tt_grid = ttk.Frame(t); self.tt_grid.pack(fill="both", expand=True, padx=12, pady=4)

    def update_tt_choices(self, keep=False):
        if not hasattr(self, "tt_grid"):
            return
        done = [n for n in (BASIC, GREEDY, BT) if self.results.get(n, {}).get("slot_of")]
        self.tt_alg_box["values"] = done
        if self.tt_alg.get() not in done:
            self.tt_alg.set(done[-1] if done else "")
        pick = 2 if self.tt_mode.get() == "Teacher" else 3      # class = (id, subject, teacher, group)
        names = sorted({c[pick] for c in self.classes})
        self.tt_who_box["values"] = names
        if self.tt_who.get() not in names:
            self.tt_who.set(names[0] if names else "")
        self.build_timetable()

    def build_timetable(self):
        for w in self.tt_grid.winfo_children():
            w.destroy()
        res = self.results.get(self.tt_alg.get())
        if not res or not res["slot_of"]:
            tk.Label(self.tt_grid, text="Run an algorithm first (tab 2 or tab 4), then come back here.",
                     font=("Segoe UI", 12), fg="#6b7689").pack(pady=60)
            return
        days, periods, slot_of = self.days(), self.periods(), res["slot_of"]
        by_slot = {}
        for c in sorted(slot_of):
            by_slot.setdefault(slot_of[c], []).append(c)
        room_of = {c: i + 1 for ids in by_slot.values() for i, c in enumerate(ids)}   # Room 1, 2, 3 ... inside a slot
        subjects = sorted({c[1] for c in self.classes})
        teacher_view = self.tt_mode.get() == "Teacher"
        who = self.tt_who.get()
        for d in range(days):
            tk.Label(self.tt_grid, text=DAY_NAMES[d], font=("Segoe UI", 10, "bold"), bg="#1b2a49", fg="white", pady=4).grid(row=0, column=d + 1, sticky="nsew", padx=1, pady=1)
        for p in range(periods):
            tk.Label(self.tt_grid, text=f"Period {p + 1}", font=("Segoe UI", 10, "bold"), bg="#1b2a49", fg="white", padx=8).grid(row=p + 1, column=0, sticky="nsew", padx=1, pady=1)
            for d in range(days):
                slot = p * days + d                      # slot number <-> (day, period)
                text, bg = "", "#eef1f6"
                for c in by_slot.get(slot, []):
                    _, subject, teacher, group = self.info[c]
                    if (teacher == who) if teacher_view else (group == who):
                        text = f"{subject}\n{group if teacher_view else teacher}\nRoom {room_of[c]}"
                        bg = PASTELS[subjects.index(subject) % len(PASTELS)]
                tk.Label(self.tt_grid, text=text, bg=bg, font=("Segoe UI", 9), height=3).grid(row=p + 1, column=d + 1, sticky="nsew", padx=1, pady=1)
        for d in range(days + 1):
            self.tt_grid.columnconfigure(d, weight=1 if d else 0)

    # ------------------------------------------------------------------ TAB 4: compare
    def build_compare_tab(self):
        t = self.tabs[3]
        ttk.Button(t, text="\u25b6  Run all 3 algorithms on this data", command=self.run_all).pack(anchor="w", padx=12, pady=10)
        cols = ("alg", "slots", "ms", "clashes", "steps", "status")
        self.cmp_tree = ttk.Treeview(t, columns=cols, show="headings", height=4)
        for c, h, w in zip(cols, ("Algorithm", "Slots used", "Time (ms)", "Clashes", "Steps", "Status"), (240, 100, 100, 90, 90, 200)):
            self.cmp_tree.heading(c, text=h); self.cmp_tree.column(c, width=w, anchor="center")
        self.cmp_tree.pack(fill="x", padx=12)
        self.cmp_note = tk.Label(t, text="", bg=BG, font=("Segoe UI", 10), fg="#1b2a49", anchor="w", justify="left")
        self.cmp_note.pack(fill="x", padx=12, pady=6)
        self.cmp_canvas = tk.Canvas(t, height=300, bg="white", highlightthickness=1, highlightbackground="#d5dbe6")
        self.cmp_canvas.pack(fill="both", expand=True, padx=12, pady=(0, 12))

    def run_all(self):
        if not self.need_classes():
            return
        self.stop_play()
        for name in (BASIC, GREEDY, BT):
            self.results[name] = run_algo(name, self.classes, self.graph, self.rooms(), self.total_slots())
        self.tt_alg.set(BT if self.results[BT]["slot_of"] else GREEDY)
        self.update_compare_table()
        self.update_tt_choices()

    def slots_of(self, name):
        r = self.results.get(name)
        return len(set(r["slot_of"].values())) if r and r["slot_of"] else None

    def update_compare_table(self):
        if not hasattr(self, "cmp_tree"):
            return
        self.cmp_tree.delete(*self.cmp_tree.get_children())
        for name in (BASIC, GREEDY, BT):
            r = self.results.get(name)
            if r:
                clashes = len(check_timetable(self.classes, r["slot_of"], self.rooms())) if r["slot_of"] else "-"
                self.cmp_tree.insert("", "end", values=(name, self.slots_of(name) or "-", f"{r['ms']:.2f}", clashes, r["steps"], r["status"]))
        self.draw_bars()

    def draw_bars(self):
        cv = self.cmp_canvas
        cv.delete("all")
        if not self.results:
            self.cmp_note.config(text="Press the button to compare the three algorithms.")
            return
        lb = lower_bound(self.classes, self.rooms())
        self.cmp_note.config(text=f"Lower bound = {lb} slots: no timetable can use fewer.  Fewer slots is better; backtracking finds the best, greedy is fastest.")
        colours = {BASIC: "#0b7f8b", GREEDY: "#6b5ce7", BT: "#d9482b"}
        for ci, (title, key) in enumerate([("Slots used (lower is better)", "slots"), ("Time in ms", "ms")]):
            x0 = 60 + ci * 560
            cv.create_text(x0, 20, anchor="w", text=title, font=("Segoe UI", 11, "bold"), fill="#1b2a49")
            vals = {n: (self.slots_of(n) if key == "slots" else self.results[n]["ms"]) if n in self.results else None for n in colours}
            top = max([v for v in vals.values() if v] + ([lb] if key == "slots" else []) + [0.001])
            base = 250
            for i, n in enumerate(colours):
                bx = x0 + 30 + i * 150
                v = vals[n]
                if v is None:
                    cv.create_text(bx + 35, base - 15, text="gave up" if n in self.results else "not run", fill="#b91c1c", font=("Segoe UI", 10, "bold"))
                else:
                    h = max(2, v / top * 180)
                    cv.create_rectangle(bx, base - h, bx + 70, base, fill=colours[n], outline="")
                    cv.create_text(bx + 35, base - h - 10, text=f"{v:.2f}" if key == "ms" else str(v), font=("Segoe UI", 10, "bold"))
                cv.create_text(bx + 35, base + 14, text=SHORT[n], font=("Segoe UI", 10))
            if key == "slots":
                y = base - lb / top * 180
                cv.create_line(x0, y, x0 + 480, y, dash=(5, 3), fill="#444")
                cv.create_text(x0 + 482, y, anchor="w", text=f"lower bound {lb}", font=("Segoe UI", 9))


if __name__ == "__main__":
    App().mainloop()
