"""RUN THIS FILE:   python main.py          (12 sample classes)
                    python main.py 30       (30 random classes)
"""
import sys
import time

from algo1_graph_coloring import basic_coloring
from algo2_greedy import greedy
from algo3_backtracking import backtracking
from checker import check_timetable
from conflict_graph import build_graph, lower_bound
from data import ROOMS, SAMPLE_CLASSES, TOTAL_SLOTS, random_classes
from show import show_timetable

classes = random_classes(int(sys.argv[1])) if len(sys.argv) > 1 else SAMPLE_CLASSES

print("STEP 1: INPUT")
print(f"  {len(classes)} classes, {ROOMS} rooms, {TOTAL_SLOTS} time slots in a week")
if len(classes) <= 15:
    for c in classes:
        print(f"  class {c[0]:>2}: {c[1]:<10} {c[2]:<7} {c[3]}")

print("\nSTEP 2: CONFLICT GRAPH")
graph = build_graph(classes)
edges = sum(len(v) for v in graph.values()) // 2
print(f"  {len(classes)} dots (classes), {edges} lines (clashes)")
print(f"  Lower bound = {lower_bound(classes, ROOMS)} slots (no timetable can use fewer)")

print("\nSTEP 3: RUN THE 3 ALGORITHMS")
print(f"  {'Algorithm':<22}{'Slots used':>11}{'Time (ms)':>11}{'Clashes':>9}")
results = {}

t = time.perf_counter()
r = basic_coloring(classes, graph, ROOMS, TOTAL_SLOTS)
ms = (time.perf_counter() - t) * 1000
results["1. Graph colouring"] = r
print(f"  {'1. Graph colouring':<22}{len(set(r.values())):>11}{ms:>11.2f}{len(check_timetable(classes, r, ROOMS)):>9}")

t = time.perf_counter()
r = greedy(classes, graph, ROOMS, TOTAL_SLOTS)
ms = (time.perf_counter() - t) * 1000
results["2. Greedy"] = r
print(f"  {'2. Greedy':<22}{len(set(r.values())):>11}{ms:>11.2f}{len(check_timetable(classes, r, ROOMS)):>9}")

t = time.perf_counter()
r, steps, status = backtracking(classes, graph, ROOMS, TOTAL_SLOTS)
ms = (time.perf_counter() - t) * 1000
if r:
    results["3. Backtracking"] = r
    print(f"  {'3. Backtracking':<22}{len(set(r.values())):>11}{ms:>11.2f}{len(check_timetable(classes, r, ROOMS)):>9}   ({steps} steps)")
else:
    print(f"  {'3. Backtracking':<22}{'-':>11}{ms:>11.2f}{'-':>9}   {status}")

best = results.get("3. Backtracking") or results["2. Greedy"]
print("\nSTEP 4: FINAL TIMETABLE (best result)")
show_timetable(classes, best)
