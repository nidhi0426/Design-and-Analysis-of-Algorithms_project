"""RUN:  python compare.py     -> time and slots for different input sizes (+ chart)"""
import time

from algo1_graph_coloring import basic_coloring
from algo2_greedy import greedy
from algo3_backtracking import backtracking
from conflict_graph import build_graph
from data import TOTAL_SLOTS, random_classes

SIZES = [10, 20, 30, 50, 100]
rows = []
print(f"{'Size':>5} | {'Colouring':^17} | {'Greedy':^17} | {'Backtracking':^28}")
print(f"{'':>5} | {'slots':>6} {'ms':>9} | {'slots':>6} {'ms':>9} | {'slots':>6} {'ms':>9} {'steps':>8}")
for n in SIZES:
    classes = random_classes(n)
    rooms = max(3, n // 8)
    graph = build_graph(classes)

    t = time.perf_counter(); a = basic_coloring(classes, graph, rooms, TOTAL_SLOTS); ta = (time.perf_counter() - t) * 1000
    t = time.perf_counter(); b = greedy(classes, graph, rooms, TOTAL_SLOTS); tb = (time.perf_counter() - t) * 1000
    t = time.perf_counter(); c, steps, status = backtracking(classes, graph, rooms, TOTAL_SLOTS); tc = (time.perf_counter() - t) * 1000

    sa, sb = len(set(a.values())), len(set(b.values()))
    sc = len(set(c.values())) if c else None
    rows.append((n, ta, tb, tc))
    sc_txt = f"{sc:>6}" if c else f"{'gave up':>6}"
    print(f"{n:>5} | {sa:>6} {ta:>9.2f} | {sb:>6} {tb:>9.2f} | {sc_txt} {tc:>9.2f} {steps:>8}")

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.figure(figsize=(7, 4))
    plt.plot([r[0] for r in rows], [r[1] for r in rows], "o-", label="Graph colouring")
    plt.plot([r[0] for r in rows], [r[2] for r in rows], "o-", label="Greedy")
    plt.plot([r[0] for r in rows], [r[3] for r in rows], "o-", label="Backtracking")
    plt.yscale("log"); plt.xlabel("Number of classes"); plt.ylabel("Time (ms)")
    plt.title("Input size vs execution time"); plt.legend(); plt.grid(alpha=.3)
    plt.savefig("compare_chart.png", dpi=150, bbox_inches="tight")
    print("\nChart saved as compare_chart.png")
except ImportError:
    print("\n(install matplotlib to also get a chart:  pip install matplotlib)")
