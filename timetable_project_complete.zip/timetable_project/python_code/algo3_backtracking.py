"""ALGORITHM 3 - Backtracking.

Idea:  decide for k = 1, 2, 3 ... "can ALL classes fit into only k slots?"
       For each class: try a slot -> if it is safe go to the next class
       -> if we get stuck, UNDO the last choice (backtrack) and try another slot.
       The first k that works is the BEST possible answer.
Slow:  worst case O(k^V) - exponential. So we stop after `max_steps`.
"""
from conflict_graph import lower_bound
from rules import is_safe, record, why_not


class TooSlow(Exception):
    pass


def backtracking(classes, graph, rooms, total_slots, max_steps=200000, log=None):
    order = sorted(graph, key=lambda c: len(graph[c]), reverse=True)   # hard classes first
    record(log, "order", order)
    steps = 0

    def solve(i, k, slot_of, used, slots_open):
        nonlocal steps
        steps += 1
        if steps > max_steps:
            raise TooSlow
        if i == len(order):                       # every class is placed -> success
            return True
        c = order[i]
        # slots are all alike, so a class may open only ONE new slot (saves time)
        for slot in range(min(slots_open + 1, k)):
            if is_safe(c, slot, graph, slot_of, used, rooms):
                slot_of[c] = slot                 # 1. choose
                used[slot] = used.get(slot, 0) + 1
                record(log, "place", c, slot)
                if solve(i + 1, k, slot_of, used, max(slots_open, slot + 1)):   # 2. go deeper
                    return True
                del slot_of[c]                    # 3. UNDO (backtrack)
                used[slot] -= 1
                record(log, "undo", c, slot)
            else:
                record(log, "reject", c, slot, why_not(c, slot, graph, slot_of, used, rooms))
        return False

    try:
        for k in range(lower_bound(classes, rooms), total_slots + 1):
            record(log, "start_k", k)
            slot_of, used = {}, {}
            if solve(0, k, slot_of, used, 0):
                return slot_of, steps, "found"
            record(log, "failed_k", k)
    except TooSlow:
        return None, steps, "gave up (too slow)"
    return None, steps, "no solution"
