UNIVERSITY TIMETABLE OPTIMIZATION - DAA MINI PROJECT
=====================================================

1) EASIEST: double-click  1_OPEN_THIS_explainer.html
   (opens in Chrome/Edge, no installation). Press Next through the 5 steps.
   The algorithms are inside this file too (search for "ALGORITHM 1", "ALGORITHM 3").

2) PYTHON CODE (the real project code) is in the folder  python_code
   Open that folder in VS Code, then in the terminal:
       python main.py        -> text demo of the 3 algorithms
       python gui.py         -> window version with step-by-step view
       python compare.py     -> time vs input size

   ALGORITHM FILES (one each):
       python_code/algo1_graph_coloring.py   Basic graph colouring
       python_code/algo2_greedy.py           Greedy (Welsh-Powell)
       python_code/algo3_backtracking.py     Backtracking
   Support files: data.py, conflict_graph.py, rules.py, checker.py, show.py
   Explanation: python_code/README_EXPLAIN.md
